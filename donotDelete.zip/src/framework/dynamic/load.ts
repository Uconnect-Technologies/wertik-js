export default function(moduleName) {
  return {};
}
