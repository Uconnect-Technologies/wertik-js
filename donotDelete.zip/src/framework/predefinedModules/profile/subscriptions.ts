import dynamic from "./../../../framework/dynamic/index";

export default `
  ${dynamic.subscriptions.generateSubscriptionsSchema('Profile')}
`