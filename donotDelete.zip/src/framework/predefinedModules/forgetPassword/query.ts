export default `
  forgetPasswordView(input: ForgetPasswordInput): ForgetPassword
`;
