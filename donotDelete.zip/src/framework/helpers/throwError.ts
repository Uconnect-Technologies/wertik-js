export default function(message, errorCode) {
  // for = "apollo-graphql", errorCode = 500, error
  // if (for == "apollo-graphql") {
  // }else if (for == "rest-api") {
  // }
}
