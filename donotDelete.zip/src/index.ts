// Use this file to export all code from wertick js

export default {
  database: {

  },
  dynamic: {

  },
  generators: {

  },
  graphql: {

  },
  helpers: {

  },
  mailer: {

  },
  model: {

  },
  security: {

  },
  validations: {
    
  }
}